
package cpu_scheduling.project;

import java.util.Comparator;
/**
 *
 * @author Noor
 */

public class Sort implements Comparator<Process> {

    @Override
    public int compare(Process o1, Process o2) {
     Process p1=(Process) o1;
      Process p2=(Process) o2;
       
         // Compare the prirority of both process
    if (p1.getPriority()   < p2.getPriority() ) return -1; // The first process has a smaller priority 
    if (p1.getPriority()  > p2.getPriority() ) return 1;  // The first process has a larger priority 
    return 0; // Both process have the same priority 
      
       
    }
     class sortByBurst implements Comparator<Process> {
    @Override
    public int compare(Process p1, Process p2) {
        return Integer.compare(p1.getBurst_time(), p2.getBurst_time());
    }
}

    
}
