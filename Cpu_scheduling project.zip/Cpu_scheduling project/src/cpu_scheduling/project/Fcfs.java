package cpu_scheduling.project;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author Aya
 */
public class Fcfs {

    Queue<Process> processQueue = new LinkedList<>();

    public void add(String processid, int burst_time) {
        processQueue.add(new Process(processid, burst_time));

    }

    public double[] run() {
        int totalWaitingTime = 0, totalTurnaroundTime = 0;
        int currentTime = 0;
        int processCounting = processQueue.size();

        for (Process process : processQueue) {
            process.waitingtime = currentTime;
            process.turnaroundtime = process.waitingtime + process.getBurst_time();
            totalWaitingTime += process.waitingtime;
            currentTime += process.getBurst_time();
            totalTurnaroundTime += process.turnaroundtime;
        }

        float averageWaitingTime = (float) totalWaitingTime / processCounting;
        float averageTurnaroundTime = (float) totalTurnaroundTime / processCounting;
        for (Process process : processQueue) {
            System.out.println(process);
        }
        System.out.println("Average waiting time is: " + averageWaitingTime);
        System.out.println("Average turnaround time is: " + averageTurnaroundTime);

        return new double[]{averageWaitingTime, averageTurnaroundTime};
    }

    public Queue<Process> getList() {
        return processQueue;
    }

}
