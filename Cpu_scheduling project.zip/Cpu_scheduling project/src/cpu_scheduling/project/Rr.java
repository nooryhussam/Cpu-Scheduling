package cpu_scheduling.project;

import java.util.LinkedList;
import java.util.Queue;
/**
 *
 * @author Rana
 */
public class Rr {

    Queue<Process> queue = new LinkedList<>();

    public void add(String processid, int burst_time) {
        queue.add(new Process(processid, burst_time));

    }

    // Method to calculate waiting time and turnaround time for all processes
    public static void findTimes(Process[] processes, int quantum) {
        int currentTime = 0; // Track current time
        Queue<Process> queue = new LinkedList<>();

        // Add all processes to the queue
        for (Process process : processes) {
            queue.add(process);
        }

        // Process each job in a round-robin manner
        while (!queue.isEmpty()) {
            Process process = queue.poll();

            // If the remaining burst time is greater than quantum
            if (process.remainingtime > quantum) {
                currentTime += quantum;
                process.remainingtime -= quantum;

                // Re-enqueue the process with updated remaining time
                queue.add(process);
            } else {
                // If the process finishes in this quantum
                currentTime += process.remainingtime;
                process.remainingtime = 0; // Mark process as completed
                process.waitingtime = currentTime - process.getBurst_time();
                process.turnaroundtime = currentTime;
            }
        }
    }

    // Method to calculate and print average time
    public static double[] findAvgTime(Process[] processes, int quantum) {
        int totalWaitingTime = 0, totalTurnAroundTime = 0;

        // Calculate waiting time and turnaround time
        findTimes(processes, quantum);

        // Print process details
        System.out.println("PN\tBurst Time\tWaiting Time\tTurnaround Time");
        for (Process process : processes) {
            totalWaitingTime += process.waitingtime;
            totalTurnAroundTime += process.turnaroundtime;
            System.out.println(process.getProcessid() + "\t\t" + process.getBurst_time() + "\t\t" + process.waitingtime + "\t\t" + process.turnaroundtime);
        }
        // Calculate and print average waiting time and turnaround time

        double avgwaiting = (float) totalWaitingTime / processes.length;
        double avgturnaround = (float) totalTurnAroundTime / processes.length;

        System.out.println("\nAverage Waiting Time = " + (float) totalWaitingTime / processes.length);
        System.out.println("Average Turnaround Time = " + (float) totalTurnAroundTime / processes.length);

        return new double[]{avgwaiting, avgturnaround};
    }

    // Method to return the list of processes in the queue
    public Process[] getProcessesArray() {
        return queue.toArray(new Process[0]);
    }
}
