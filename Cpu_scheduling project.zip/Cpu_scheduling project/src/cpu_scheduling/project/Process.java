package cpu_scheduling.project;

/**
 *
 * @author Noor
 */
public class Process {

    public int remainingtime;
    private String Processid;
    private int burst_time;
    public int waitingtime;  //time spent waiting
    public int turnaroundtime;  // time from arrival to execution
    int arrivaltime = 0;
    private int priority;
    
    public String getProcessid() {
        return Processid;
    }

    public void setProcessid(String Processid) {
        this.Processid = Processid;
    }

    public void setBurst_time(int burst_time) {
        this.burst_time = burst_time;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getBurst_time() {
        return burst_time;
    }

    public int getPriority() {
        return priority;
    }

    //constructor
    public Process(String Processid, int burst_time, int priority) {
        this.Processid = Processid;
        this.burst_time = burst_time;

        this.priority = priority;
        this.waitingtime = 0;
        this.turnaroundtime = 0;
    }

    public Process(String Processid, int burst_time) {
        this.Processid = Processid;
        this.burst_time = burst_time;
        this.priority = 0;
        this.waitingtime = 0;
        this.turnaroundtime = 0;
        this.remainingtime = burst_time;
    }

    public Process(String Processid, int burst_time, int waitingtime, int turnaroundtime, int priority) {
        this.Processid = Processid;
        this.burst_time = burst_time;
        this.waitingtime = waitingtime;
        this.turnaroundtime = turnaroundtime;
        this.priority = priority;
    }

    public String toString() {
        return "Process ID: " + Processid + ", Burst Time: " + burst_time + ", Priority: " + priority + ", Waiting Time: " + waitingtime + ", Turnaround Time: " + turnaroundtime;
    }


}
