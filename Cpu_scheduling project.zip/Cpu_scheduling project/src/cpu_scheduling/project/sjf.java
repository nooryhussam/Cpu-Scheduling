
package cpu_scheduling.project;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Collections;
import java.util.Comparator;
/**
 *
 * @author fayrouz
 */
public class sjf {
        Queue<Process> processQueue = new LinkedList<>();

    // إضافة العمليات للطابور
    public void add(String processid, int burst_time) {
        processQueue.add(new Process(processid, burst_time));
    }

    // تشغيل الخوارزمية لحساب الوقت
    public double[] run() {
        // ترتيبات حسابية
        int totalWaitingTime = 0, totalTurnaroundTime = 0;
        int currentTime = 0;
        int processCounting = processQueue.size();

        // ترتيب العمليات حسب زمن التنفيذ (من الأقل إلى الأعلى)
        LinkedList<Process> sortedProcesses = new LinkedList<>(processQueue);

        // ترتيب العمليات حسب burst_time وأيضًا إذا كانت burst_time متساوية، نقارن بين process_id باستخدام FCFS
        Collections.sort(sortedProcesses, new Comparator<Process>() {
            @Override
            public int compare(Process p1, Process p2) {
                // إذا كانت burst_time متساوية، نقارن بين process_id باستخدام FCFS
                if (p1.getBurst_time() == p2.getBurst_time()) {
                    return p1.getProcessid().compareTo(p2.getProcessid());
                }
                // خلاف ذلك، نقارن حسب burst_time
                return Integer.compare(p1.getBurst_time(), p2.getBurst_time());
            }
        });

        // حساب وقت الانتظار ووقت الدوران
        for (Process process : sortedProcesses) {
            // وقت الانتظار هو الوقت الحالي
            process.waitingtime = currentTime;
            // وقت الدوران = وقت الانتظار + وقت التنفيذ
            process.turnaroundtime = process.waitingtime + process.getBurst_time();
            totalWaitingTime += process.waitingtime;
            currentTime += process.getBurst_time(); // زيادة الوقت الحالي حسب وقت تنفيذ العملية
            totalTurnaroundTime += process.turnaroundtime;
        }

        // حساب المتوسطات
        float averageWaitingTime = (float) totalWaitingTime / processCounting;
        float averageTurnaroundTime = (float) totalTurnaroundTime / processCounting;

        // طباعة تفاصيل العمليات
        for (Process process : sortedProcesses) {
            System.out.println(process);
        }

        // طباعة المتوسطات
        System.out.println("Average waiting time is: " + averageWaitingTime);
        System.out.println("Average turnaround time is: " + averageTurnaroundTime);

        // إرجاع المتوسطات
        return new double[]{averageWaitingTime, averageTurnaroundTime};
    }

    // إرجاع قائمة العمليات
    public Queue<Process> getList() {
        return processQueue;
    }
}
    
    

