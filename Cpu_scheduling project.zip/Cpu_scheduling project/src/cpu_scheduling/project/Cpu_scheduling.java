package cpu_scheduling.project;

import static cpu_scheduling.project.Rr.findAvgTime;
import gui.CpuSchedulingJFrame;
import java.util.LinkedList;
import java.util.Queue;

public class Cpu_scheduling {

    public static void main(String[] args) {
        // Process details with arrival time = 0
   /*     Process[] processes = {
            new Process("1", 5), // Process 1 with burst time 10
            new Process("2", 8), // Process 2 with burst time 5
            new Process("3", 6) // Process 3 with burst time 8
        };

        // Quantum time (time slice)
        int quantum = 3;

        // Calculate and display average time
        findAvgTime(processes, quantum);*/
        
    /*    sjf sjf = new sjf();

        // إضافة العمليات للطابور
        sjf.add("P1", 6);
        sjf.add("P2", 8);
        sjf.add("P3", 7);
        sjf.add("P4", 3);

        // تشغيل الخوارزمية وحساب النتائج
        sjf.run();*/

        new CpuSchedulingJFrame().setVisible(true);
    }

}
