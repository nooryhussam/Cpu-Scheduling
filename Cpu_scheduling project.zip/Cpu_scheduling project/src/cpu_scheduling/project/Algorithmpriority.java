package cpu_scheduling.project;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 *
 * @author Noor
 */
public class Algorithmpriority {

    Queue<Process> list = new LinkedList<>();

    public void add(String processid, int burst_time, int priority) {
        list.add(new Process(processid, burst_time, priority));

    }

    public double[] priority() {
        int total_waitingtime = 0;
        int total_turnaroundtime = 0;
        int currentTime = 0;
// Convert Queue to List for sorting
        // List<Process> processList = new LinkedList<>(list);

        // Sort by priority
        //   Collections.sort(processList, new Sort());
        Comparator myComparator = new Sort();
        Collections.sort((List<Process>) list, myComparator);

        // Get the size of the queue before processing
        int processCount = list.size();

        for (Process process : list) {
            process.waitingtime = currentTime;
            process.turnaroundtime = process.waitingtime + process.getBurst_time();
            total_waitingtime += process.waitingtime;
            currentTime += process.getBurst_time();
            total_turnaroundtime += process.turnaroundtime;
        }

        //calclating average waiting time and turnaround time
        double avg_Waitingtime = ((double) total_waitingtime / processCount);
        double avg_turnaroundtime = ((double) total_turnaroundtime / processCount);

        for (Process process : list) {
            System.out.println(process);
        }

        System.out.println("\nAverage Waiting Time: " + avg_Waitingtime);
        System.out.println("Average Turnaround Time: " + avg_turnaroundtime);

        return new double[]{avg_Waitingtime, avg_turnaroundtime};
    }

    // Get the list of processes
    public Queue<Process> getList() {
        return list;
    }
}
